# Popâ Ur-Mää Global Consulting Enterprise — Website 2.0

STATUS: COMPLETE STATIC SITE PACKAGE — NOT DEPLOYED / NOT PUBLISHED.

A responsive one-page public enterprise website in purple, gold and black with the founder-provided enterprise emblem.

## Included
- Founder introduction and background
- Three consulting areas (no full-time management or enterprise DJ booking)
- Cataloghaus, Rude Tymz and Popâ One AI venture directory
- Six video presentations: featured Bugatti, Rolls-Royce, archival Ten City, Rude Tymz Apparel, Cataloghaus and WOMAN
- Contact call-to-action, currently linking to the existing Merlin site until a verified direct business email is configured
- Mobile navigation, responsive styling, keyboard navigation and reduced-motion support

## Files
- `index.html` — page structure and copy
- `styles.css` — design and responsive layout
- `script.js` — navigation and contact/venture rendering
- `site-config.js` — verified venture destinations and optional direct contact email
- `assets/` — founder-supplied emblem and optimized local videos/posters

## Review locally
Extract the ZIP and open `index.html` in Chrome or Edge. For reliable testing, serve this folder with `python3 -m http.server 8000` and visit http://localhost:8000. YouTube videos require internet access and permission to embed from their respective uploaders.

## Publication gate
Do not publish, connect a custom domain, change DNS, or purchase anything without explicit founder approval. Before deployment, verify final public contact destination and external links, test all six videos and responsive layouts in the intended hosting environment. The site currently has no contact form backend; the contact button deliberately goes to the existing public Merlin contact route rather than pretending to submit messages.

## Media
- Bugatti (featured): https://www.youtube.com/watch?v=TlAgJmYaCc4
- Rolls-Royce: https://www.youtube.com/watch?v=G-zAT9KxaNQ
- Ten City — That's the Way Love Is (archival): https://youtu.be/Y_edhEpE_YM
- Rude Tymz Apparel: local MP4
- Cataloghaus: local MP4
- WOMAN: local MP4 (title supplied by founder)

No video or company logo was invented. Local MP4s were optimized for delivery. The site is an executable deliverable, not a design mockup.

## Launch checklist
- Confirm direct enterprise contact address or approved contact form destination. Current contact button points to existing Merlin contact page.
- Test all embedded YouTube videos and local MP4 playback on the actual host.
- Check desktop/mobile layout and keyboard navigation.
- Obtain explicit founder approval before publishing or changing DNS.


CONTACT: The visitor inquiry form is implemented but activates only after a verified public enterprise email is entered in `site-config.js`. Until then the contact button opens the existing Merlin contact page. The form uses mailto (visitor email client), not a server-side submission service; no paid backend is required.

Contact: popa.ur.maa@consultant.com (mailto form, requires visitor email app; not a server-side submission).
Popâ One AI: https://www.facebook.com/profile.php?id=61595277427960 (founder-supplied).
